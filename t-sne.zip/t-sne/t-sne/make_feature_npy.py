# -*- coding: utf-8 -*-
"""
Generate the placeholder feature .npy files -- so the figures produced in
t-sne(2) carry the same content as the baseline scripts in t-sne/
--------------------------------------------------------------------------
Approach: reuse the 2-D cloud parameters and random seeds of
t-sne/tsne_both.py (see REFERENCE_CLOUDS in tsne_utils.py) and embed each
feature set's 2-D layout *isometrically* into D dimensions:
    X = P @ Q.T ,  Q: D×2 orthonormal basis   (every pairwise distance kept)
then add a tiny full-dimensional noise term, so the matrix is a genuine
(N, D) array that PCA / t-SNE can process normally.

Consequences:
    - the .npy holds a real high-dimensional feature matrix (whose manifold
      happens to be exactly the layout of the baseline figure);
    - the plotting scripts read it and run a genuine t-SNE, so the 2-D
      coordinates are computed by t-SNE, not copied from disk;
    - tsne_utils.align_to_reference() then puts the result back into the
      baseline frame, so the figure can be compared point by point.

Note: this is placeholder data, not an experimental result. For real features
run extract_features.py instead and draw with --align none
(see README_t_sne.md).

Usage:
    python make_feature_npy.py            # never overwrites, only reports
    python make_feature_npy.py --force    # overwrite the existing .npy (back up first)
"""

import argparse
import json
import os

import numpy as np

import tsne_utils as tu

HERE = tu.HERE


def lift_to_features(P, D, seed, noise=0.005):
    """Embed the 2-D layout isometrically into D dimensions:
    X = P @ Q.T (Q is a D×2 orthonormal basis) plus a tiny noise term."""
    rng = np.random.default_rng(seed)
    Q, _ = np.linalg.qr(rng.standard_normal((D, 2)))     # D×2, orthonormal columns
    X = P @ Q.T                                          # N×D, 2-D distances kept
    X = X + rng.normal(0.0, noise, size=X.shape)         # full-dim noise, manifold intact
    return X.astype(np.float32)


def build_set(name, D, seed, noise=0.005):
    """Return (X [N,D] float32, y [N] int64) in baseline order (Real first)."""
    P, y = tu.reference_cloud(name)
    return lift_to_features(P, D, seed, noise), y


# Seeds for the embedding basis (fixed values, so the run is reproducible;
# unrelated to the layout of the labels)
EMBED_SEEDS = {'bb_cn': 101, 'our_cn': 202, 'bb_rs': 303, 'our_rs': 404}


def main():
    ap = argparse.ArgumentParser(
        description='generate placeholder .npy files from the baseline cloud parameters')
    ap.add_argument('--out-dir', default=HERE)
    ap.add_argument('--force', action='store_true',
                    help='overwrite the existing .npy files (default: keep them, '
                         'so real exported features are never lost)')
    ap.add_argument('--noise', type=float, default=0.005,
                    help='standard deviation of the full-dim noise '
                         '(relative to the coordinate scale, default 0.005)')
    args = ap.parse_args()

    existing = [f for f in os.listdir(args.out_dir) if f.endswith('.npy')]
    if existing and not args.force:
        print('%d .npy file(s) already present: %s'
              % (len(existing), ', '.join(sorted(existing))))
        print('Nothing was written, so real exported features are not '
              'overwritten. Pass --force to overwrite (back them up first).')
        return

    manifest = {'note': 'placeholder features: 2-D reference layouts of the '
                        'baseline scripts, isometrically embedded into D dims; '
                        'NOT experimental results',
                'label_convention': '0=Real, 1=Fake',
                'source': 'tsne/tsne_both.py parameters & seeds '
                          '(tsne_utils.REFERENCE_CLOUDS)',
                'sets': {}}

    for name, spec in tu.FEATURE_SPECS.items():
        X, y = build_set(name, spec['dim'], EMBED_SEEDS[name], noise=args.noise)
        np.save(os.path.join(args.out_dir, spec['feat']), X)
        np.save(os.path.join(args.out_dir, spec['label']), y)
        manifest['sets'][name] = dict(
            file=spec['feat'], dim=int(X.shape[1]), n=int(X.shape[0]),
            n_real=int((y == 0).sum()), n_fake=int((y == 1).sum()),
            reference=tu.REFERENCE_CLOUDS[name])
        print('[write] %-16s X=%s  Real=%d Fake=%d'
              % (spec['feat'], X.shape, int((y == 0).sum()), int((y == 1).sum())))

    with open(os.path.join(args.out_dir, 'feature_manifest.json'), 'w',
              encoding='utf-8') as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    print('[write] feature_manifest.json')


if __name__ == '__main__':
    main()
