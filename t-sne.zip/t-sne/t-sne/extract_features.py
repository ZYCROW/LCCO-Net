# -*- coding: utf-8 -*-
"""
Export deep features from a trained checkpoint -> feat_*.npy / label_*.npy
(the real data source of the t-SNE figures)
--------------------------------------------------------------------------
This script is the proper source of the .npy files: it walks the test set once
and stores the deep feature matrices the network actually produces, so that
tsne_lcco.py / tsne_lcco_resnet.py read model outputs instead of placeholders.

Every feature set comes from the same checkpoint; the only difference is
whether our modules are in the path:
    bb_*  : bare backbone branch only (no LHFE, no difference-guided CBAM)
    our_* : the full LCCO-Net (LHFE -> two branches -> diff-guided CBAM)
Both take the Process 2 (deep) feature and apply global average pooling, so the
widths match the paper architecture:
    ConvNeXt-Tiny  stage-2 -> 384 dims
    ResNet branch  layer2  -> 512 dims

Usage (needs torch / torchvision / timm and a models/ tree of the same version):
    python extract_features.py --data-root D:/data/AIGCDetect_testset/progan \\
        --checkpoint ../LCCO-Net_code/checkpoint/checkpoint-train-on-progan.pth \\
        --backbone convnext --n-per-class 500
    python extract_features.py --data-root ... --backbone resnet --n-per-class 500
Outputs: feat_bb_<tag>.npy / feat_our_<tag>.npy / label_*.npy (tag = cn or rs)
"""

import argparse
import os
import sys

import numpy as np


def _require(mods):
    missing = []
    for m in mods:
        try:
            __import__(m)
        except ImportError:
            missing.append(m)
    if missing:
        raise SystemExit(
            'Missing dependencies: %s\nInstall them with '
            'pip install torch torchvision timm, or run this script inside the '
            "project's conda environment." % ', '.join(missing))


def build_model(code_root, backbone):
    """Build TwoBranchLCCONet from the project code, putting code_root on sys.path."""
    if code_root and code_root not in sys.path:
        sys.path.insert(0, code_root)
    from models.lcco_net import TwoBranchLCCONet      # noqa: E402
    return TwoBranchLCCONet(backbone=backbone)


def load_state_dict(model, ckpt_path):
    """Fault-tolerant loading: tolerates the 'model'/'module.' prefixes and the
    older branch1/branch2 naming.

    Returns (missing_keys, unexpected_keys) so the caller can judge whether the
    checkpoint really matches the current code.
    """
    import torch

    raw = torch.load(ckpt_path, map_location='cpu')
    if isinstance(raw, dict) and 'model' in raw:
        raw = raw['model']
    state = {}
    for k, v in raw.items():
        if not hasattr(v, 'shape'):        # skip optimizer / scaler entries
            continue
        k = k.replace('module.', '')
        # old two-branch naming branch1/branch2 -> current branch_upper/branch_lower
        k = k.replace('branch1.', 'branch_upper.').replace('branch2.', 'branch_lower.')
        state[k] = v

    missing, unexpected = model.load_state_dict(state, strict=False)
    return missing, unexpected


class FeatureExtractor:
    """One forward pass yields both feature sets (same images, same weights,
    so the two panels stay comparable).

    bb  : deep pooled features of the bare backbone branch (raw image in,
          without LHFE / CBAM)
    our : deep features of the full LCCO-Net (LHFE-enhanced image in, after the
          diff-guided CBAM); with feat='diff' the cross-branch difference
          f_u,d - f_l,d that feeds the classifier is returned instead
    Returns the concatenated vector [bb | our]; collect() splits it afterwards.
    """

    def __init__(self, model, feat='deep_u'):
        import torch.nn as nn
        import torch.nn.functional as F

        class _Dual(nn.Module):
            def __init__(self, m, feat, F):
                super().__init__()
                self.m, self.feat, self.F = m, feat, F

            def forward(self, x):
                import torch

                _, deep_bb = self.m.branch_upper(x)          # bare backbone, raw image
                bb = self.F.adaptive_avg_pool2d(deep_bb, 1).flatten(1)
                out = self.m(x)                             # (logits, deep_u, deep_l, ...)
                deep_u, deep_l = out[1], out[2]
                our = (deep_u - deep_l) if self.feat == 'diff' else deep_u
                return torch.cat([bb, our], dim=1)

        self.net = _Dual(model, feat, F).eval()


def build_loader(data_root, image_size, batch_size, num_workers):
    """0_real / 1_fake layout (same as data/datasets.py)."""
    from torch.utils.data import DataLoader
    from torchvision import datasets, transforms

    tf = transforms.Compose([
        transforms.Resize((image_size, image_size)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225]),
    ])
    ds = datasets.ImageFolder(data_root, transform=tf)
    class_to_idx = ds.class_to_idx                    # expect {'0_real':0, '1_fake':1}
    if class_to_idx.get('0_real') != 0 or class_to_idx.get('1_fake') != 1:
        raise SystemExit('The directory must contain the 0_real/ and 1_fake/ '
                         'sub-folders, found: %s' % class_to_idx)
    loader = DataLoader(ds, batch_size=batch_size, shuffle=False,
                        num_workers=num_workers, pin_memory=True)
    return ds, loader, class_to_idx


def balanced_indices(labels, n_per_class, seed=0):
    """Indices keeping at most n_per_class samples per class
    (n_per_class <= 0 means all)."""
    if n_per_class is None or n_per_class <= 0:
        return np.arange(len(labels))
    rng = np.random.default_rng(seed)
    picked = []
    for c in (0, 1):
        ids = np.flatnonzero(labels == c)
        if ids.size > n_per_class:
            ids = rng.choice(ids, size=n_per_class, replace=False)
        picked.append(ids)
    idx = np.sort(np.concatenate(picked))
    return idx


def collect(extractor, loader, device):
    import torch

    feats, labels = [], []
    with torch.no_grad():
        for i, (x, y) in enumerate(loader, 1):
            x = x.to(device, non_blocking=True)
            f = extractor.net(x)
            feats.append(f.float().cpu().numpy())
            labels.append(y.numpy())
            if i % 20 == 0:
                print('  batch %d  (%d samples)' % (i, sum(len(a) for a in feats)))
    return np.concatenate(feats).astype(np.float32), np.concatenate(labels)


def main():
    ap = argparse.ArgumentParser(description='export deep feature .npy files')
    ap.add_argument('--data-root', required=True,
                    help='test-set directory containing 0_real/ and 1_fake/')
    ap.add_argument('--checkpoint', required=True, help='path to the .pth weights')
    ap.add_argument('--backbone', choices=('resnet', 'convnext'), required=True)
    ap.add_argument('--code-root', default=os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        'LCCO-Net_code'), help='project root that contains models/')
    ap.add_argument('--feature', choices=('deep_u', 'diff'), default='deep_u',
                    help='which feature our_* uses: deep_u = deep-branch '
                         'features (default), diff = the cross-branch difference '
                         'fed to the classifier')
    ap.add_argument('--out-dir', default=os.path.dirname(os.path.abspath(__file__)))
    ap.add_argument('--tag', default=None,
                    help='file-name suffix; defaults to convnext->cn, resnet->rs')
    ap.add_argument('--image-size', type=int, default=256)
    ap.add_argument('--n-per-class', type=int, default=0,
                    help='max images per class for the t-SNE figure '
                         '(0 = all; 500 matches the paper)')
    ap.add_argument('--seed', type=int, default=0, help='sampling seed')
    ap.add_argument('--batch-size', type=int, default=32)
    ap.add_argument('--num-workers', type=int, default=4)
    args = ap.parse_args()

    _require(['torch', 'torchvision', 'timm'])
    import torch

    tag = args.tag or ('cn' if args.backbone == 'convnext' else 'rs')
    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    print('[1/4] Building the model (%s) ...' % args.backbone)
    model = build_model(args.code_root, args.backbone)

    print('[2/4] Loading weights %s ...' % args.checkpoint)
    missing, unexpected = load_state_dict(model, args.checkpoint)
    if missing:
        print('  [warn] %d parameters did not match (first 5): %s'
              % (len(missing), missing[:5]))
        if len(missing) > 0.2 * len(list(model.state_dict())):
            print('  [warn] the mismatch ratio is too high; the checkpoint '
                  'probably belongs to an older architecture, so the exported '
                  'features may not be trustworthy -- export them with '
                  'matching code first.')
    if unexpected:
        print('  [info] %d extra keys in the checkpoint (first 5): %s'
              % (len(unexpected), unexpected[:5]))
    model.to(device).eval()

    print('[3/4] Walking the test set %s ...' % args.data_root)
    ds, loader, class_to_idx = build_loader(args.data_root, args.image_size,
                                            args.batch_size, args.num_workers)
    print('  classes: %s  (%d images in total)' % (class_to_idx, len(ds)))

    # One forward pass yields both bb and our features (stored concatenated,
    # split apart below)
    dual, labels = collect(FeatureExtractor(model, args.feature), loader, device)
    dim = dual.shape[1] // 2
    feats_bb, feats_our = dual[:, :dim], dual[:, dim:]

    # Class-balanced sampling: bb and our share the same indices, so both
    # panels show exactly the same images
    idx = balanced_indices(labels, args.n_per_class, seed=args.seed)
    feats_our, feats_bb, labels = feats_our[idx], feats_bb[idx], labels[idx]

    print('[4/4] Saving .npy ...')
    for prefix, X in (('our', feats_our), ('bb', feats_bb)):
        f_path = os.path.join(args.out_dir, 'feat_%s_%s.npy' % (prefix, tag))
        np.save(f_path, X)
        print('  [write] %s  shape=%s  dtype=%s' % (f_path, X.shape, X.dtype))
    np.save(os.path.join(args.out_dir, 'label_our_%s.npy' % tag), labels.astype(np.int64))
    np.save(os.path.join(args.out_dir, 'label_bb_%s.npy' % tag), labels.astype(np.int64))
    print('  [write] label_*_%s.npy  0=Real %d  1=Fake %d'
          % (tag, int((labels == 0).sum()), int((labels == 1).sum())))


if __name__ == '__main__':
    main()
