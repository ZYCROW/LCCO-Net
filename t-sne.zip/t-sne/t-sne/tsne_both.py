# -*- coding: utf-8 -*-
"""
Produce every artefact of the two figure groups in one run
(ConvNeXt group + ResNet group + 2x2 overview)
--------------------------------------------------------------------------
Difference from the old tsne_both.py: it no longer fakes 2-D clouds with
make_cluster(); all four feature sets are read from .npy and each one runs its
own t-SNE.

Run:
    python tsne_both.py
Outputs:
    tsne_real_fake_comparison.png            ConvNeXt group (a) Backbone / (b) Ours
    tsne_real_fake_comparison_ResNet.png     ResNet   group (a) Backbone / (b) Ours
    tsne_comparison_overview.png             2x2 overview (quick self-check)
"""

import argparse
import os

from tsne_utils import GROUPS, HERE, plot_feature_pair, plot_overview


def main():
    ap = argparse.ArgumentParser(description='generate both Real/Fake t-SNE figures in one run')
    ap.add_argument('--perplexity', type=float, default=50.0)
    ap.add_argument('--pca-dim', type=int, default=2,
                    help='PCA dimension before t-SNE; 0 disables PCA')
    ap.add_argument('--normalize', choices=('none', 'zscore', 'l2'),
                    default='none')
    ap.add_argument('--align', choices=('reference', 'none'),
                    default='reference',
                    help='reference=map back to the baseline frame; '
                         'none=fit the frame to the data')
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--no-overview', action='store_true',
                    help='skip the 2x2 overview figure')
    args = ap.parse_args()

    kw = dict(perplexity=args.perplexity, pca_dim=args.pca_dim,
              seed=args.seed, normalize=args.normalize, align=args.align)

    for key in ('convnext', 'resnet'):
        g = GROUPS[key]
        plot_feature_pair(g['left'], g['right'], os.path.join(HERE, g['out']), **kw)
        print()

    if not args.no_overview:
        plot_overview(os.path.join(HERE, 'tsne_comparison_overview.png'), **kw)


if __name__ == '__main__':
    main()
