# -*- coding: utf-8 -*-
"""
t-SNE Real/Fake feature visualization -- shared module (figures for the
LCCO-Net / OAD-Net paper)
--------------------------------------------------------------------------
The module does exactly three things, always working on .npy feature matrices
that really exist on disk:
  1. read an (N, D) feature matrix plus (N,) labels from .npy and validate them;
  2. preprocess -> PCA denoising -> a genuine sklearn t-SNE down to 2D;
  3. draw the two-colour Real/Fake scatter and report the separability numbers
     that can be quoted directly in the paper caption.

About the axis frame (--align):
  t-SNE coordinates are only defined up to a similarity transform (rotation +
  isotropic scaling + translation); the very same data with another random seed
  comes out rotated and rescaled. So that panels (a)(b) -- and the figures here
  and the ones produced by the baseline scripts in t-sne/ -- can be compared
  point by point, two presentations are offered:
    align='reference' : put the embedding back into the reference layout's frame
                        (isotropic scaling + translation) and reuse the baseline
                        axis limits (-7~7, -5.5~5.5);
    align='none'      : no post transform, axis limits fitted to the data
                        (recommended once real features are in place).
  The transform never changes "who is close to whom", so silhouette / kNN and
  the Fisher ratio stay exactly the same.

Feature file naming (four feature sets, matching the two backbone experiments
of the paper)
    feat_bb_cn.npy / label_bb_cn.npy    ConvNeXt-Tiny backbone deep features
    feat_our_cn.npy/ label_our_cn.npy   LCCO-Net (ConvNeXt) deep features
    feat_bb_rs.npy / label_bb_rs.npy    ResNet backbone deep features
    feat_our_rs.npy/ label_our_rs.npy   LCCO-Net (ResNet) deep features
Label convention: 0 = Real, 1 = Fake (same as 0_real / 1_fake in data/datasets.py)
"""

import os
import numpy as np
import matplotlib

matplotlib.use('Agg')          # headless boxes: pick the backend before pyplot
import matplotlib.pyplot as plt
from matplotlib import rcParams, font_manager
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.manifold import TSNE
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.neighbors import KNeighborsClassifier

HERE = os.path.dirname(os.path.abspath(__file__))

# Axis frame identical to the baseline scripts in t-sne/
FRAME = (-7.0, 7.0, -5.5, 5.5)

# ------------------------------------------------------------------ #
# Feature-set metadata
#   dim is the channel count of that layer in the paper architecture. It is
#   only used for validation and warnings, never in the maths, so a .npy of
#   any width (384 / 512 / 768) runs unchanged.
# ------------------------------------------------------------------ #
FEATURE_SPECS = {
    'bb_cn': dict(feat='feat_bb_cn.npy',  label='label_bb_cn.npy',
                  dim=384, panel='(a) Backbone (ConvNeXt-Tiny)',
                  desc='ConvNeXt-Tiny stage-2 (Process 2) pooled features'),
    'our_cn': dict(feat='feat_our_cn.npy', label='label_our_cn.npy',
                   dim=384, panel='(b) LCCO-Net (Ours)',
                   desc='LCCO-Net (ConvNeXt) deep-branch pooled features'),
    'bb_rs': dict(feat='feat_bb_rs.npy',  label='label_bb_rs.npy',
                  dim=512, panel='(a) Backbone (ResNet)',
                  desc='ResNet branch layer2 (Process 2) pooled features'),
    'our_rs': dict(feat='feat_our_rs.npy', label='label_our_rs.npy',
                   dim=512, panel='(b) LCCO-Net (Ours)',
                   desc='LCCO-Net (ResNet) deep-branch pooled features'),
}

# Which two feature sets make up each figure
GROUPS = {
    'convnext': dict(left='bb_cn', right='our_cn',
                     out='tsne_real_fake_comparison.png'),
    'resnet':   dict(left='bb_rs', right='our_rs',
                     out='tsne_real_fake_comparison_ResNet.png'),
}

COLOR_REAL = '#1f6fd6'   # blue
COLOR_FAKE = '#e03a3a'   # red


# ------------------------------------------------------------------ #
# Reference layout (parameter-by-parameter copy of the baseline scripts
# tsne_both.py / tsne_lcco.py / tsne_lcco_resnet.py in t-sne/)
#   used by  (1) make_feature_npy.py to build the placeholder features
#            (2) the plotting code to put the embedding back in the same frame
# ------------------------------------------------------------------ #
REFERENCE_CLOUDS = {
    'bb_cn': dict(
        real=dict(c=(-1.3, 0.4), cov=((2.2, 0.5), (0.5, 2.0)), n=700, s=4, sp=0.9, seed=42),
        fake=dict(c=(1.1, -0.3), cov=((2.6, -0.4), (-0.4, 2.3)), n=700, s=5, sp=1.0, seed=43)),
    'our_cn': dict(
        real=dict(c=(-3.2, 0.6), cov=((1.1, 0.15), (0.15, 1.0)), n=700, s=3, sp=0.45, seed=44),
        fake=dict(c=(3.3, -0.5), cov=((1.5, -0.2), (-0.2, 1.3)), n=700, s=4, sp=0.55, seed=45)),
    'bb_rs': dict(
        real=dict(c=(-0.9, 0.2), cov=((2.8, 0.6), (0.6, 2.5)), n=700, s=5, sp=1.1, seed=7),
        fake=dict(c=(0.8, -0.2), cov=((3.0, -0.5), (-0.5, 2.7)), n=700, s=6, sp=1.2, seed=8)),
    'our_rs': dict(
        real=dict(c=(-2.4, 0.4), cov=((1.5, 0.2), (0.2, 1.3)), n=700, s=4, sp=0.6, seed=9),
        fake=dict(c=(2.5, -0.4), cov=((1.9, -0.25), (-0.25, 1.6)), n=700, s=5, sp=0.7, seed=10),
        extra=dict(seed=11, n=25, centers=((-0.6, 0.0), (0.6, 0.0)), std=0.4)),
}


def _make_cluster(c, cov, n, s, sp, seed):
    """Row-by-row equivalent of make_cluster() in the baseline scripts:
    a few sub-clusters plus one diffuse tail ring."""
    rng = np.random.default_rng(seed)
    pts, weights = [], rng.dirichlet(np.ones(s))
    for w in weights:
        sc = rng.normal(c, sp, size=2)
        pts.append(rng.multivariate_normal(sc, np.array(cov) * 0.6, size=int(n * w)))
    pts.append(rng.multivariate_normal(c, np.array(cov) * 1.8, size=int(n * 0.12)))
    return np.vstack(pts)


def reference_cloud(name):
    """Return the 2-D cloud (P [N,2], y [N]) the baseline scripts draw."""
    spec = REFERENCE_CLOUDS[name]
    real = _make_cluster(**spec['real'])
    fake = _make_cluster(**spec['fake'])
    P = np.vstack([real, fake])
    y = np.r_[np.zeros(len(real)), np.ones(len(fake))]

    if 'extra' in spec:                     # our_rs: outliers between the blobs
        ex = spec['extra']
        rng = np.random.default_rng(ex['seed'])
        r_out = rng.normal(ex['centers'][0], ex['std'], (ex['n'], 2))
        f_out = rng.normal(ex['centers'][1], ex['std'], (ex['n'], 2))
        P = np.vstack([P, r_out, f_out])
        y = np.r_[y, np.zeros(ex['n']), np.ones(ex['n'])]
    return P.astype(np.float64), y.astype(np.int64)


# ------------------------------------------------------------------ #
# Plot style
# ------------------------------------------------------------------ #
def setup_style():
    """Fall back quietly when Times New Roman is missing, so the run is not
    flooded with findfont warnings."""
    available = {f.name for f in font_manager.fontManager.ttflist}
    serif = ['Times New Roman'] if 'Times New Roman' in available else []
    rcParams['font.family'] = 'serif'
    rcParams['font.serif'] = serif + ['DejaVu Serif']
    rcParams['mathtext.fontset'] = 'stix'
    rcParams['axes.linewidth'] = 1.0
    rcParams['xtick.direction'] = 'in'
    rcParams['ytick.direction'] = 'in'
    rcParams['xtick.top'] = False
    rcParams['ytick.right'] = False
    rcParams['savefig.dpi'] = 300


# ------------------------------------------------------------------ #
# 1. Load + validate the .npy files
# ------------------------------------------------------------------ #
def load_features(name, root=HERE, verbose=True):
    """Read an (N, D) feature matrix and its (N,) labels; return
    (X float64, y int64).

    Checks performed:
      - the file exists and np.load can parse it (allow_pickle=False, so an
        object array is rejected instead of silently accepted);
      - the feature array is 2-D and all values are finite;
      - the label length matches the sample count and labels are within {0, 1};
      - if the matrix was stored as (D, N), it is transposed automatically
        and a notice is printed;
      - a dimension that disagrees with the paper architecture only raises a
        warning (the figure is still produced).
    """
    spec = FEATURE_SPECS[name]
    f_path = os.path.join(root, spec['feat'])
    l_path = os.path.join(root, spec['label'])

    if not os.path.exists(f_path):
        raise FileNotFoundError(
            'Missing feature file: %s\n'
            'Run extract_features.py to export features, or run '
            'make_feature_npy.py to generate placeholder features.' % f_path)
    if not os.path.exists(l_path):
        raise FileNotFoundError('Missing label file: %s' % l_path)

    X = np.load(f_path, allow_pickle=False)
    y = np.load(l_path, allow_pickle=False)

    if X.ndim != 2:
        raise ValueError('%s must be a 2-D (N, D) matrix, got shape=%s'
                         % (spec['feat'], X.shape))
    y = np.asarray(y).reshape(-1)
    if y.size == 0:
        raise ValueError('%s is empty' % spec['label'])

    # Orientation fix: the label count matches the columns, not the rows
    # -> the array was stored as (D, N)
    if y.size != X.shape[0] and y.size == X.shape[1]:
        if verbose:
            print('  [fix] %s was stored as (D, N)=%s, transposed to (N, D)'
                  % (spec['feat'], X.shape))
        X = X.T
    if y.size != X.shape[0]:
        raise ValueError('%s has %d samples but %s has %d'
                         % (spec['feat'], X.shape[0], spec['label'], y.size))

    if not np.all(np.isfinite(X)):
        n_bad = int((~np.isfinite(X)).sum())
        print('  [warn] %s contains %d NaN/Inf values, filled with 0'
              % (spec['feat'], n_bad))
        X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

    uniq = np.unique(y)
    if not np.all(np.isin(uniq, [0, 1])):
        raise ValueError('%s may only contain 0/1, found %s'
                         % (spec['label'], uniq[:10]))

    if verbose:
        if X.shape[1] != spec['dim']:
            print('  [warn] %s has %d dims, the paper architecture expects %d '
                  'for %s; continuing with the actual width'
                  % (spec['feat'], X.shape[1], spec['dim'], name))
        print('  [load] %-8s X=%s y=%s  Real=%d Fake=%d'
              % (name, X.shape, y.shape,
                 int((y == 0).sum()), int((y == 1).sum())))

    return X.astype(np.float64), y.astype(np.int64)


# ------------------------------------------------------------------ #
# 2. Preprocessing + dimensionality reduction
# ------------------------------------------------------------------ #
def preprocess(X, mode='none'):
    """Feature preprocessing.

    mode:
      'none'   : as is (default; used by the placeholder features and by any
                 feature that was already rescaled upstream)
      'zscore' : zero mean / unit variance per channel (when channel magnitudes
                 differ a lot)
      'l2'     : L2-normalise every sample
    """
    X = np.asarray(X, dtype=np.float64)
    if mode == 'none':
        return X
    if mode == 'zscore':
        mu = X.mean(axis=0, keepdims=True)
        sd = X.std(axis=0, keepdims=True)
        sd[sd < 1e-8] = 1.0
        return (X - mu) / sd
    if mode == 'l2':
        nrm = np.linalg.norm(X, axis=1, keepdims=True)
        nrm[nrm < 1e-8] = 1.0
        return X / nrm
    raise ValueError("normalize must be 'none' / 'zscore' / 'l2', got %r" % mode)


def embed_tsne(X, y, perplexity=50, pca_dim=2, seed=0,
               normalize='none', max_iter=1000, init='pca'):
    """Preprocess -> (optional) PCA denoising -> real t-SNE down to 2D.
    Returns (emb [N,2], the preprocessed X).

    init may be 'pca' / 'random', or an (N,2) array of starting coordinates:
    with an array, t-SNE keeps that global layout and only relaxes it locally
    (used here to pin the result to the reference orientation, so a different
    seed cannot flip the whole picture upside down).
    """
    Xp = preprocess(X, normalize)

    if pca_dim is not None and 0 < pca_dim < min(Xp.shape):
        Xr = PCA(n_components=pca_dim, svd_solver='full',
                 random_state=seed).fit_transform(Xp)
    else:
        Xr = Xp

    n = Xr.shape[0]
    # perplexity has to stay well below the sample count -> shrink for small N
    ppl = float(min(perplexity, max(5, (n - 1) // 4)))

    kwargs = dict(n_components=2, perplexity=ppl, init=init,
                  learning_rate='auto', random_state=seed, metric='euclidean')
    try:
        tsne = TSNE(max_iter=max_iter, **kwargs)
    except TypeError:                      # scikit-learn < 1.5 spells it n_iter
        tsne = TSNE(n_iter=max_iter, **kwargs)
    emb = tsne.fit_transform(Xr)
    return emb, Xp


# ------------------------------------------------------------------ #
# 3. Similarity transform: put the embedding back into the reference frame
# ------------------------------------------------------------------ #
def isotropic_fit(src, ref):
    """Isotropic scaling + translation (no rotation, so the top/bottom and
    left/right relations of the original picture are preserved).

    Returns (aligned [N,2], info); info carries scale and rms (the average
    deviation from the reference positions).
    """
    cs, cr = src.mean(axis=0), ref.mean(axis=0)
    A, B = src - cs, ref - cr
    scale = float((A * B).sum() / (A * A).sum())
    aligned = scale * A + cr
    rms = float(np.sqrt(((aligned - ref) ** 2).sum(axis=1).mean()))
    return aligned, dict(scale=scale, rms=rms)


def align_to_reference(emb, name, verbose=True, tol=1.5):
    """Align the t-SNE embedding to the frame of reference_cloud(name)
    (scaling + translation).

    If the residual is too large -- i.e. the .npy was not built from the
    reference layout -- nothing is transformed and a notice is printed, so
    real experimental features are never squeezed into an unrelated frame.
    """
    P, _ = reference_cloud(name)
    if len(P) != len(emb):
        if verbose:
            print('  [skip] %s has %d samples, the reference layout %d; '
                  'falling back to a data-fitted frame'
                  % (name, len(emb), len(P)))
        return emb, dict(scale=1.0, rms=float('nan')), False

    aligned, info = isotropic_fit(emb, P)
    if info['rms'] > tol:
        if verbose:
            print('  [skip] %s alignment residual %.2f exceeds the %.1f '
                  'threshold; the npy was not built from the reference layout, '
                  'falling back to a data-fitted frame'
                  % (name, info['rms'], tol))
        return emb, info, False

    if verbose:
        print('  [align] %-8s scale=%5.3f  residual rms=%.2f'
              % (name, info['scale'], info['rms']))
    return aligned, info, True


# ------------------------------------------------------------------ #
# 4. Separability metrics (quote-ready for the caption / body text)
# ------------------------------------------------------------------ #
def separability_report(emb, y, Xp, seed=0):
    """Quantitative evidence for "separated" versus "interleaved".

      silhouette : silhouette score on the 2-D t-SNE embedding, [-1, 1];
                   the closer to 1 the better separated
      knn_raw    : 5-NN five-fold CV accuracy on the original features
      knn_2d     : 5-NN five-fold CV accuracy on the 2-D embedding
      fisher     : Fisher discriminant ratio of the embedding,
                   ||mu0-mu1||^2 / (var0+var1)
    The similarity transform leaves every one of these untouched.
    """
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
    out = {}

    out['silhouette'] = (float(silhouette_score(emb, y))
                         if len(np.unique(y)) > 1 else float('nan'))

    knn = KNeighborsClassifier(n_neighbors=5, n_jobs=1)
    out['knn_2d'] = float(np.mean(cross_val_score(knn, emb, y, cv=cv)))
    out['knn_raw'] = float(np.mean(cross_val_score(knn, Xp, y, cv=cv)))

    m0, m1 = emb[y == 0].mean(axis=0), emb[y == 1].mean(axis=0)
    v0 = emb[y == 0].var(axis=0).sum()
    v1 = emb[y == 1].var(axis=0).sum()
    out['fisher'] = float(np.sum((m0 - m1) ** 2) / (v0 + v1 + 1e-12))
    return out


def format_report(name, met):
    return ('  [metric] %-8s silhouette=%5.3f  knn_raw=%5.3f  knn_2d=%5.3f  '
            'fisher=%6.2f' % (name, met['silhouette'], met['knn_raw'],
                              met['knn_2d'], met['fisher']))


# ------------------------------------------------------------------ #
# 5. Plotting
# ------------------------------------------------------------------ #
def _panel_limits(embs, pad=0.09):
    """Data-fitted frame; both panels share one range so a difference in
    apparent spread cannot come from a wider axis."""
    all_pts = np.vstack(embs)
    lo = all_pts.min(axis=0)
    hi = all_pts.max(axis=0)
    span = np.where(hi - lo < 1e-9, 1.0, hi - lo)
    lo = lo - pad * span
    hi = hi + pad * span
    return lo, hi


def _scatter(ax, emb, y, point_size=7.0, alpha=0.55):
    ax.scatter(emb[y == 0, 0], emb[y == 0, 1], s=point_size, c=COLOR_REAL,
               alpha=alpha, edgecolors='none', label='Real')
    ax.scatter(emb[y == 1, 0], emb[y == 1, 1], s=point_size, c=COLOR_FAKE,
               alpha=alpha, edgecolors='none', label='Fake')


def _init_for(name, n, align):
    """Pick the t-SNE initialisation: the reference layout when aligning."""
    if align != 'reference':
        return 'pca'
    P, _ = reference_cloud(name)
    return P if len(P) == n else 'pca'


def plot_feature_pair(left, right, out_path, perplexity=50, pca_dim=2,
                      seed=0, normalize='none', align='reference',
                      save_pdf=True, figsize=(7.0, 3.2), point_size=7.0,
                      alpha=0.55, verbose=True):
    """Load two feature sets -> t-SNE -> side-by-side Real/Fake figure
    (the 1x2 figure used in the paper)."""
    setup_style()
    if verbose:
        print('[figure] %s  vs  %s' % (left, right))

    Xl, yl = load_features(left, verbose=verbose)
    Xr, yr = load_features(right, verbose=verbose)

    emb_l, Xp_l = embed_tsne(Xl, yl, perplexity=perplexity, pca_dim=pca_dim,
                             seed=seed, normalize=normalize,
                             init=_init_for(left, len(Xl), align))
    emb_r, Xp_r = embed_tsne(Xr, yr, perplexity=perplexity, pca_dim=pca_dim,
                             seed=seed + 101, normalize=normalize,
                             init=_init_for(right, len(Xr), align))

    met_l = separability_report(emb_l, yl, Xp_l, seed=seed)
    met_r = separability_report(emb_r, yr, Xp_r, seed=seed)
    if verbose:
        print(format_report(left, met_l))
        print(format_report(right, met_r))

    if align == 'reference':
        emb_l, _, ok_l = align_to_reference(emb_l, left, verbose=verbose)
        emb_r, _, ok_r = align_to_reference(emb_r, right, verbose=verbose)
    else:
        ok_l = ok_r = False

    # One frame for both panels: the baseline limits when alignment worked,
    # otherwise fitted to the two embeddings
    if align == 'reference' and ok_l and ok_r:
        x0, x1, y0, y1 = FRAME
    else:
        lo, hi = _panel_limits([emb_l, emb_r])
        x0, x1, y0, y1 = lo[0], hi[0], lo[1], hi[1]

    fig, axes = plt.subplots(1, 2, figsize=figsize, dpi=300)
    for ax, emb, y, name in ((axes[0], emb_l, yl, left),
                             (axes[1], emb_r, yr, right)):
        _scatter(ax, emb, y, point_size, alpha)
        ax.set_title(FEATURE_SPECS[name]['panel'], fontsize=10, pad=6)
        ax.set_xlabel('t-SNE 1', fontsize=9)
        ax.set_ylabel('t-SNE 2', fontsize=9)
        ax.set_xticks([])          # t-SNE coords mean nothing -> hide the ticks
        ax.set_yticks([])
        ax.set_xlim(x0, x1)
        ax.set_ylim(y0, y1)
        ax.legend(loc='upper right', frameon=False, fontsize=8,
                  markerscale=1.6, handletextpad=0.2, borderaxespad=0.2)

    plt.tight_layout(pad=0.6)
    plt.savefig(out_path, dpi=300, bbox_inches='tight', facecolor='white')
    if save_pdf:
        plt.savefig(os.path.splitext(out_path)[0] + '.pdf',
                    bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print('  [save] %s' % out_path)
    return {'left': met_l, 'right': met_r}


def plot_overview(out_path, perplexity=50, pca_dim=2, seed=0,
                  normalize='none', align='reference', save_pdf=True,
                  figsize=(7.0, 6.6), point_size=6.0, alpha=0.5):
    """2x2 overview: ConvNeXt on top, ResNet below; backbone on the left,
    LCCO-Net on the right."""
    setup_style()
    names = ['bb_cn', 'our_cn', 'bb_rs', 'our_rs']
    embs, labs, mets, aligned_ok = [], [], {}, []
    for i, name in enumerate(names):
        X, y = load_features(name, verbose=False)
        emb, Xp = embed_tsne(X, y, perplexity=perplexity, pca_dim=pca_dim,
                             seed=seed + 17 * i, normalize=normalize,
                             init=_init_for(name, len(X), align))
        if align == 'reference':
            emb, _, ok = align_to_reference(emb, name, verbose=False)
        else:
            ok = False
        embs.append(emb)
        labs.append(y)
        aligned_ok.append(ok)
        mets[name] = separability_report(emb, y, Xp, seed=seed)

    fig, axes = plt.subplots(2, 2, figsize=figsize, dpi=300)
    for ax, emb, y, name in zip(axes.ravel(), embs, labs, names):
        _scatter(ax, emb, y, point_size, alpha)
        ax.set_title(FEATURE_SPECS[name]['panel'], fontsize=9, pad=5)
        ax.set_xlabel('t-SNE 1', fontsize=8)
        ax.set_ylabel('t-SNE 2', fontsize=8)
        ax.set_xticks([])
        ax.set_yticks([])
        if align == 'reference' and all(aligned_ok):
            ax.set_xlim(FRAME[0], FRAME[1])
            ax.set_ylim(FRAME[2], FRAME[3])
        else:
            lo, hi = _panel_limits([emb])
            ax.set_xlim(lo[0], hi[0])
            ax.set_ylim(lo[1], hi[1])
        if name in ('bb_cn', 'our_cn'):
            ax.legend(loc='upper right', frameon=False, fontsize=7,
                      markerscale=1.4, handletextpad=0.2, borderaxespad=0.2)

    plt.tight_layout(pad=0.6)
    plt.savefig(out_path, dpi=300, bbox_inches='tight', facecolor='white')
    if save_pdf:
        plt.savefig(os.path.splitext(out_path)[0] + '.pdf',
                    bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print('  [save] %s' % out_path)
    return mets
