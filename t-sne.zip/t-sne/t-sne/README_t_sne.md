# t-SNE Real/Fake Feature Distributions -- Notes and Usage

The files in this folder have been through two rounds of rework; the current
state is described below.

**First rework (make the code actually read .npy)** -- three problems fixed:

| # | Original problem | What it does now |
|---|---|---|
| 1 | `tsne_lcco.py` / `tsne_lcco_resnet.py` / `tsne_both.py` called `make_cluster()` and drew fake 2-D clouds, **never reading a single .npy**, yet the axes said "t-SNE 1 / t-SNE 2" | All three scripts now read `feat_*.npy`, preprocess, run PCA, run a genuine `sklearn.manifold.TSNE`, then plot |
| 2 | `tsne_with_npy.py` generated features and plotted in the same run, so every execution overwrote the .npy files on disk | Responsibilities split: `extract_features.py` exports real features (or `make_feature_npy.py` writes placeholders); `tsne_with_npy.py` only does the read-back self-check and the metric table, it never writes .npy |
| 3 | All four feature sets were hard-coded to 512 dims, which contradicts the paper architecture (ConvNeXt-Tiny stage-2 has only 384 channels) | ConvNeXt group is 384 dims, ResNet group 512; `tsne_utils.py` uses the dim only for validation warnings, so the code is decoupled from the width |

**Second rework (make the output match the three baseline scripts in `t-sne/`)**
-- see section 4.

---

## 1. What each file does

| File | Purpose |
|---|---|
| `tsne_utils.py` | Shared module: read .npy (dim / label / NaN / orientation checks), preprocessing, PCA, t-SNE, reference layout and alignment, separability metrics, plotting |
| `tsne_lcco.py` | ConvNeXt group figure: (a) Backbone vs (b) LCCO-Net -> `tsne_real_fake_comparison.png/.pdf` |
| `tsne_lcco_resnet.py` | ResNet group figure: (a) Backbone vs (b) LCCO-Net (Ours, ResNet) -> `tsne_real_fake_comparison_ResNet.png/.pdf` |
| `tsne_both.py` | Produces both figures plus the 2x2 overview `tsne_comparison_overview.png` |
| `tsne_with_npy.py` | Read-back self-check + separability metric table -> `tsne_metrics.csv` |
| `extract_features.py` | **The real data source**: loads a checkpoint, runs the test set, exports `feat_*.npy` / `label_*.npy` |
| `make_feature_npy.py` | Placeholder generator (built from the baseline cloud parameters, **not an experimental result**) |
| `feature_manifest.json` | Records each npy's origin, width, sample count and cloud parameters |
| `README_t_sne.md` | This file |
| `_backup_chinese_comments_20261111/` | The seven `.py` files as they were before the English-comment pass (Chinese comments and docstrings), kept for comparison or rollback |

## 2. .npy format (same as the 0_real / 1_fake convention of `data/datasets.py`)

```
feat_<who>_<bb>.npy   float32, shape = (N, D)   deep features of N samples
label_<who>_<bb>.npy  int64,   shape = (N,)     0 = Real, 1 = Fake
    <who> in {bb, our}   bb = bare backbone, our = the full LCCO-Net
    <bb>  in {cn, rs}    cn = ConvNeXt-Tiny (D=384), rs = ResNet (D=512)
```

The four feature sets currently in this folder (the sample count follows from
the Dirichlet sampling inside the baseline `make_cluster()`, so it is not an
exact 700):

| Feature set | shape | Real / Fake | Origin |
|---|---|---|---|
| `feat_bb_cn.npy`  | (1563, 384) | 782 / 781 | ConvNeXt-Tiny stage-2 (Process 2) global average pooling |
| `feat_our_cn.npy` | (1563, 384) | 782 / 781 | LCCO-Net (ConvNeXt) deep-branch pooling |
| `feat_bb_rs.npy`  | (1562, 512) | 781 / 781 | ResNet branch layer2 (Process 2) global average pooling |
| `feat_our_rs.npy` | (1615, 512) | 808 / 807 | LCCO-Net (ResNet) deep-branch pooling |

> **These npy files are placeholders right now** (see the `note` field of
> `feature_manifest.json`): their content is the 2-D layout built from the cloud
> parameters and seeds of `t-sne/tsne_both.py`, embedded isometrically into D
> dimensions. The pre-rework originals are kept in the sibling folder
> `t-sne(2)/_backup_before_fix_20261110/` (this copy does not carry them). To
> switch to real features, run `extract_features.py` to overwrite the files --
> see section 5.

## 3. Generating the figures

```bash
python tsne_lcco.py                 # ConvNeXt group
python tsne_lcco_resnet.py          # ResNet group
python tsne_both.py                 # both figures + 2x2 overview
python tsne_with_npy.py             # metric table only, no figure
```

Common options (all three plotting scripts):

```
--perplexity 50      perplexity (30~50 for roughly 1500 samples; the script
                     automatically keeps it below N/4)
--pca-dim 2          PCA before t-SNE; 2 keeps only the feature manifold,
                     0 disables PCA
--normalize none     preprocessing; zscore (per-channel) or l2 (per-sample)
                     also available
--align reference    same axis frame as the baseline scripts in t-sne/;
                     none = frame fitted to the data
--seed 0             random seed, results reproducible
```

Output is a 300 dpi PNG plus a vector PDF (the PDF drops straight into a LaTeX
template). Both panels share one coordinate range, so "one side looks more
scattered" can never be an artefact of a wider axis.

## 4. Consistency with the baseline scripts in `t-sne/` (`tsne_both.py` etc.)

The baseline scripts do not read npy at all: they draw a 2-D Gaussian mixture
with `make_cluster()`. To get "still reads npy and runs a genuine t-SNE, but the
figure matches the baseline", three things were done:

1. **Reference layout imported verbatim**: `tsne_utils.REFERENCE_CLOUDS` copies
   the baseline parameters item by item (centre, covariance, sub-cluster count,
   spread, seed, plus the extra 25+25 outliers of `our_rs`); `_make_cluster()`
   is line-for-line equivalent to the baseline `make_cluster()`, so
   `reference_cloud(name)` reproduces **exactly the same points** as the
   baseline figure.
2. **Placeholder features built from that layout**: `make_feature_npy.py`
   embeds the 2-D layout isometrically into D dimensions (`X = P @ Q.T`, with
   `Q` a D×2 orthonormal basis, distances preserved) and adds 0.005
   full-dimensional noise, so the .npy is a genuine (N, D) high-dimensional
   matrix whose manifold happens to be that layout.
3. **Result put back into the same frame when plotting**: `embed_tsne()`
   initialises t-SNE with the reference layout (`init=<N×2 array>`, which keeps
   the up/down, left/right orientation of the original picture); after
   convergence one **isotropic scaling + translation** is applied
   (`isotropic_fit()`, no rotation, no mirroring), and the baseline frame
   `FRAME = (-7, 7, -5.5, 5.5)` is reused.

Measured alignment residual (the `align_rms` column of `tsne_metrics.csv`, in
axis units):

| Feature set | Residual rms | Note |
|---|---|---|
| `bb_cn`  | 0.62 | same frame and same cluster positions as the baseline |
| `our_cn` | 0.55 | same |
| `bb_rs`  | 0.73 | same |
| `our_rs` | 0.62 | same |

> **Please keep this in mind**: t-SNE is a non-linear embedding that only
> preserves neighbourhood structure. Redrawn through it, the same cloud matches
> in global position / orientation / scale, **but points cannot coincide
> one-by-one** (the 0.55~0.73 residual above is t-SNE's own distortion; the
> clusters are about 2~3 units wide). In other words: composition, cluster
> centres, overlap, colours, legend and axis frame match the baseline; the local
> density texture differs.
> A pixel-perfect reproduction of the baseline would require skipping t-SNE and
> scatter-plotting the stored 2-D coordinates directly -- that path is
> deliberately not provided, since it would abandon the "genuine t-SNE"
> premise.
>
> Once real features are in place, switch to `--align none`:
> `align_to_reference()` skips the transform automatically (and says so) when
> the residual exceeds 1.5, so real features are never squeezed into an
> unrelated frame.

## 5. Exporting real features (replacing placeholders with model output)

```bash
python extract_features.py \
    --data-root D:/datasets/AIGCDetect_testset/progan \
    --checkpoint "../LCCO-Net_code/checkpoint/checkpoint-train-on-progan.pth" \
    --backbone convnext --n-per-class 500
```

- `--data-root` must follow the `0_real/`, `1_fake/` layout;
- `--n-per-class 500` samples 500 images per class in a balanced way (0 means
  all), and `bb_*` / `our_*` share the same indices, so both panels show the
  same images;
- `bb_*` uses the same weights but **skips LHFE and the difference-guided
  CBAM** (bare backbone), so that the only difference between panels (a) and (b)
  is "our modules" -- otherwise the comparison does not hold;
- `--feature diff` exports the cross-branch difference `f_u,d - f_l,d` that
  feeds the classifier instead;
- the script tolerates the `branch1/branch2` naming (older two-branch code) and
  the `model` / `module.` prefixes, and prints the missing / unexpected keys. If
  the missing ratio is high, the checkpoint belongs to a different version of
  `models/`, so the features are not trustworthy and must be exported with
  matching code;
- **torch is not installed on this machine, so the script has only been
  syntax-checked, never run end to end.** If the first run complains about a
  parameter name or a mismatched return tuple, send me the traceback and I will
  adapt it to the actual version of `models/`.

## 6. Separability metrics of the current artefacts

Measured by `tsne_with_npy.py` (`tsne_metrics.csv`; perplexity=50, PCA 2 dims,
`normalize=none`, `align=reference`):

| Feature set | silhouette | 5-NN (raw features) | 5-NN (2-D) | Fisher ratio |
|---|---|---|---|---|
| `bb_cn`  | 0.290 | 0.789 | 0.794 | 1.10 |
| `our_cn` | 0.692 | 0.996 | 0.998 | 8.51 |
| `bb_rs`  | 0.146 | 0.705 | 0.700 | 0.42 |
| `our_rs` | 0.572 | 0.963 | 0.962 | 4.79 |

That is: with the same backbone, adding LHFE + CBAM + CCO moves Real/Fake in
feature space from "interleaved" to "clearly separated", and the Fake side
splits into several sub-clusters (the several modes left by several generators),
matching the paper's observation of "real images single-modal, synthetic images
bi-/multi-modal".

> These numbers come from placeholder data; they exist to validate the pipeline
> and the readability of the figure and **do not represent model performance**.
> After switching to real features, re-run `python tsne_with_npy.py` to get the
> numbers that can go into the paper.

## 7. Conventional choices for the figure and its hyper-parameters

- About 780 test images per class (1500+ points in total), the scale used by
  feature-distribution figures in mainstream detection papers;
- Features are the global average pooling output of the last stage (Process 2),
  not classifier logits, so the plot does not turn a decision into "feature
  space";
- t-SNE is initialised with PCA (`init='pca'`) plus `learning_rate='auto'`,
  perplexity 50;
- Tick labels are hidden (t-SNE coordinates carry no physical meaning); only the
  `t-SNE 1 / t-SNE 2` axis labels remain;
- Colour encodes Real/Fake only (blue/red), and the quantitative metrics above
  are quoted in the caption, which pre-empts the "looks separated but is not"
  objection.

## 8. Runtime environment

```
python 3.13 / numpy 2.5 / scikit-learn 1.9 / matplotlib 3.11   (verified here)
extract_features.py additionally needs torch + torchvision + timm
                                                              (not installed here, not run)
```

Install the dependencies with `pip install numpy scikit-learn matplotlib`
