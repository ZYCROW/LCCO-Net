# -*- coding: utf-8 -*-
"""
Real/Fake t-SNE comparison for the ConvNeXt-Tiny group
(panels (a) vs (b) of the paper figure)
--------------------------------------------------------------------------
Reads genuine high-dimensional feature matrices from disk instead of faking
2-D clouds:
    feat_bb_cn.npy    Backbone (ConvNeXt-Tiny) deep features
    feat_our_cn.npy   LCCO-Net (ConvNeXt) deep features
    label_*.npy       0 = Real, 1 = Fake
Pipeline: read npy -> PCA(2) to keep the feature manifold -> sklearn t-SNE
          -> (optional) similarity transform back to the baseline frame
          -> side-by-side scatter

Run:
    python tsne_lcco.py                      # same frame as t-sne/tsne_lcco.py
    python tsne_lcco.py --align none         # no post transform, fitted frame
    python tsne_lcco.py --perplexity 30 --seed 7
Outputs:
    tsne_real_fake_comparison.png / .pdf
"""

import argparse
import os

from tsne_utils import GROUPS, HERE, plot_feature_pair

GROUP = GROUPS['convnext']


def main():
    ap = argparse.ArgumentParser(
        description='Real/Fake feature t-SNE comparison, ConvNeXt group')
    ap.add_argument('--perplexity', type=float, default=50.0,
                    help='t-SNE perplexity (30~50 for roughly 1500 samples)')
    ap.add_argument('--pca-dim', type=int, default=2,
                    help='PCA dimension before t-SNE; 0 disables PCA')
    ap.add_argument('--normalize', choices=('none', 'zscore', 'l2'),
                    default='none', help='feature preprocessing mode')
    ap.add_argument('--align', choices=('reference', 'none'),
                    default='reference',
                    help='reference=map back to the baseline frame; '
                         'none=fit the frame to the data')
    ap.add_argument('--seed', type=int, default=0, help='random seed')
    ap.add_argument('--out', default=os.path.join(HERE, GROUP['out']),
                    help='output image path')
    args = ap.parse_args()

    plot_feature_pair(GROUP['left'], GROUP['right'], args.out,
                      perplexity=args.perplexity, pca_dim=args.pca_dim,
                      seed=args.seed, normalize=args.normalize,
                      align=args.align)


if __name__ == '__main__':
    main()
