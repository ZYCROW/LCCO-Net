# -*- coding: utf-8 -*-
"""
.npy read-back self-check + separability metric table
(no plotting, numbers only)
--------------------------------------------------------------------------
Purpose: confirm that feat_*.npy / label_*.npy on disk really parse, that their
width matches the paper architecture, and write the t-SNE separability metrics
to a CSV that can be quoted in the paper body / caption.

Run:
    python tsne_with_npy.py
Outputs:
    console self-check table + tsne_metrics.csv
"""

import argparse
import csv
import os

import numpy as np

import tsne_utils as tu


def inspect_file(path):
    """Read-only check; never involved in plotting."""
    if not os.path.exists(path):
        return dict(path=path, ok=False, info='missing file')
    try:
        a = np.load(path, allow_pickle=False)
    except Exception as exc:                        # noqa: BLE001
        return dict(path=path, ok=False, info='read failed: %s' % exc)
    info = 'shape=%s dtype=%s' % (a.shape, a.dtype)
    if np.issubdtype(a.dtype, np.number) and a.size:
        info += '  finite=%s' % bool(np.all(np.isfinite(a)))
    return dict(path=path, ok=True, info=info)


def main():
    ap = argparse.ArgumentParser(description='npy self-check + t-SNE metric table')
    ap.add_argument('--perplexity', type=float, default=50.0)
    ap.add_argument('--pca-dim', type=int, default=2)
    ap.add_argument('--normalize', choices=('none', 'zscore', 'l2'),
                    default='none')
    ap.add_argument('--align', choices=('reference', 'none'),
                    default='reference',
                    help='same as the plotting scripts: with reference the '
                         'reference layout initialises t-SNE')
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--csv', default=os.path.join(tu.HERE, 'tsne_metrics.csv'))
    args = ap.parse_args()

    print('=== 1. File read-back self-check ===')
    all_ok = True
    for name, spec in tu.FEATURE_SPECS.items():
        for key in ('feat', 'label'):
            r = inspect_file(os.path.join(tu.HERE, spec[key]))
            all_ok &= r['ok']
            print('  [%s] %-18s %s' % ('ok ' if r['ok'] else 'FAIL', spec[key], r['info']))
    if not all_ok:
        print('\nSome files are missing or corrupted. Run extract_features.py '
              'to export features, or make_feature_npy.py --force to generate '
              'placeholder features.')

    print('\n=== 2. t-SNE separability metrics ===')
    rows = []
    for i, name in enumerate(['bb_cn', 'our_cn', 'bb_rs', 'our_rs']):
        try:
            X, y = tu.load_features(name, verbose=False)
        except Exception as exc:                    # noqa: BLE001
            print('  [skip] %-8s %s' % (name, exc))
            continue
        init = 'pca'
        if args.align == 'reference':                # same initialisation as the plots
            P, _ = tu.reference_cloud(name)
            if len(P) == len(X):
                init = P
        emb, Xp = tu.embed_tsne(X, y, perplexity=args.perplexity,
                                pca_dim=args.pca_dim, seed=args.seed + i,
                                normalize=args.normalize, init=init)
        met = tu.separability_report(emb, y, Xp, seed=args.seed)
        print(tu.format_report(name, met))
        rms = ''
        if args.align == 'reference' and len(init) == len(X):
            _, info = tu.isotropic_fit(emb, tu.reference_cloud(name)[0])
            rms = round(info['rms'], 3)
        rows.append(dict(name=name, dim=X.shape[1], n=X.shape[0],
                         n_real=int((y == 0).sum()), n_fake=int((y == 1).sum()),
                         silhouette=round(met['silhouette'], 4),
                         knn_raw=round(met['knn_raw'], 4),
                         knn_2d=round(met['knn_2d'], 4),
                         fisher=round(met['fisher'], 4),
                         align_rms=rms))

    if rows:
        with open(args.csv, 'w', newline='', encoding='utf-8-sig') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print('\n[write] %s' % args.csv)

    print('\nNote: a higher silhouette (2-D) and knn_* (5-NN five-fold accuracy) '
          'mean Real/Fake separate better; fisher is the between-class / '
          'within-class variance ratio of the 2-D embedding.')


if __name__ == '__main__':
    main()
