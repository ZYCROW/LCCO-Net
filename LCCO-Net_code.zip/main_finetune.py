import os
import csv
import random
import argparse
import datetime
import numpy as np
import time
import json
from pathlib import Path

import torch
from torchvision import transforms

import timm
from timm.data.mixup import Mixup
from timm.loss import LabelSmoothingCrossEntropy, SoftTargetCrossEntropy
from timm.utils import ModelEma
from optim_factory import create_optimizer, LayerDecayValueAssigner

from models.resnet import resnet50
from models.lcco_net import lcco_net_resnet, lcco_net_convnext
from data.datasets import TrainDataset
from engine_finetune import train_one_epoch, evaluate

import utils
from utils import NativeScalerWithGradNormCount as NativeScaler
from utils import str2bool


def get_args_parser():

    parser = argparse.ArgumentParser('LCCO-Net fine-tuning', add_help=False)
    parser.add_argument('--jpeg_factor', type=int, default=None)
    parser.add_argument('--blur_sigma', type=float, default=None)
    parser.add_argument('--mask_ratio', type=float, default=None)
    parser.add_argument('--mask_patch_size', type=int, default=None)
    parser.add_argument('--transform_mode', type=str, default='crop')

    # Training config (paper: batch 32, 100 epochs, AdamW, wd 0.01).
    parser.add_argument('--batch_size', default=32, type=int,
                        help='Per GPU batch size')
    parser.add_argument('--epochs', default=100, type=int)
    parser.add_argument('--update_freq', default=1, type=int,
                        help='gradient accumulation steps')

    # Model parameters.
    parser.add_argument('--model', default='LCCONet', type=str, metavar='MODEL',
                        help='model architecture (default: LCCONet)')
    parser.add_argument('--backbone', default='resnet', type=str,
                        choices=['resnet', 'convnext'],
                        help='backbone of the two branches (default: resnet)')
    parser.add_argument('--input_size', default=256, type=int,
                        help='image input size')
    parser.add_argument('--layer_decay_type', type=str, choices=['single', 'group'],
                        default='single',
                        help="Layer decay strategies.")

    # LCCO-Net loss / module hyper-parameters.
    parser.add_argument('--csdd_weight', default=0.5, type=float,
                        help='lambda: weight of the CSDD loss in L = CE + lambda*CSDD')
    parser.add_argument('--fad_beta', default=0.5, type=float,
                        help='beta1: weight of FAD inside CSDD')
    parser.add_argument('--cco_beta', default=0.5, type=float,
                        help='beta2: weight of CCO inside CSDD')
    parser.add_argument('--alpha', default=1.0, type=float,
                        help='LHFE high-frequency amplification coefficient')
    parser.add_argument('--base_margin', default=0.5, type=float,
                        help='initial base discrepancy margin')
    parser.add_argument('--margin_coeff', default=0.30, type=float,
                        help='coefficient of normalized high-frequency energy in the adaptive margin')

    # EMA related parameters.
    parser.add_argument('--model_ema', action='store_true')
    parser.add_argument('--model_ema_decay', type=float, default=0.9999)
    parser.add_argument('--model_ema_force_cpu', action='store_true')
    parser.add_argument('--model_ema_eval', action='store_true',
                        help='Using ema to eval during training.')

    # Optimization parameters.
    parser.add_argument('--clip_grad', type=float, default=None, metavar='NORM',
                        help='Clip gradient norm (default: None, no clipping)')
    parser.add_argument('--weight_decay', type=float, default=0.01,
                        help='weight decay (default: 0.01)')
    parser.add_argument('--lr', type=float, default=None, metavar='LR',
                        help='learning rate (absolute lr)')
    parser.add_argument('--blr', type=float, default=5e-4, metavar='LR',
                        help='base learning rate: absolute_lr = base_lr * total_batch_size / 256')
    parser.add_argument('--layer_decay', type=float, default=1.0)
    parser.add_argument('--min_lr', type=float, default=1e-6, metavar='LR',
                        help='lower lr bound for cyclic schedulers that hit 0 (1e-6)')
    parser.add_argument('--warmup_epochs', type=int, default=20, metavar='N',
                        help='epochs to warmup LR, if scheduler supports')
    parser.add_argument('--warmup_steps', type=int, default=-1, metavar='N',
                        help='num of steps to warmup LR, will overload warmup_epochs if set > 0')
    parser.add_argument('--opt', default='adamw', type=str, metavar='OPTIMIZER',
                        help='Optimizer (default: "adamw"')
    parser.add_argument('--opt_eps', default=1e-8, type=float, metavar='EPSILON',
                        help='Optimizer Epsilon (default: 1e-8)')
    parser.add_argument('--opt_betas', default=None, type=float, nargs='+', metavar='BETA',
                        help='Optimizer Betas (default: None, use opt default)')
    parser.add_argument('--momentum', type=float, default=0.9, metavar='M',
                        help='SGD momentum (default: 0.9)')
    parser.add_argument('--weight_decay_end', type=float, default=None,
                        help="Final value of the weight decay.")
    parser.add_argument('--smoothing', type=float, default=0.1,
                        help='Label smoothing (default: 0.1)')

    # Mixup params.
    parser.add_argument('--mixup', type=float, default=0.,
                        help='mixup alpha, mixup enabled if > 0.')
    parser.add_argument('--cutmix', type=float, default=0.,
                        help='cutmix alpha, cutmix enabled if > 0.')
    parser.add_argument('--cutmix_minmax', type=float, nargs='+', default=None,
                        help='cutmix min/max ratio, overrides alpha and enables cutmix')
    parser.add_argument('--mixup_prob', type=float, default=1.0,
                        help='Probability of performing mixup or cutmix when either/both is enabled')
    parser.add_argument('--mixup_switch_prob', type=float, default=0.5,
                        help='Probability of switching to cutmix when both mixup and cutmix enabled')
    parser.add_argument('--mixup_mode', type=str, default='batch',
                        help='How to perform mixup/cutmix params. Per "batch", pair", or "elem"')

    # Finetuning params.
    parser.add_argument('--pretrained', default=True, help='finetune from checkpoint')
    parser.add_argument('--global_pool', action='store_true')
    parser.set_defaults(global_pool=True)
    parser.add_argument('--head_init_scale', default=0.001, type=float,
                        help='classifier head initial scale, typically adjusted in fine-tuning')
    parser.add_argument('--model_key', default='model|module', type=str,
                        help='which key to load from saved state dict, usually model or model_ema')
    parser.add_argument('--model_prefix', default='', type=str)

    # Dataset parameters.
    parser.add_argument('--num_train', default=10000000000, type=int,
                        help="Number of training images, including real and fake")
    parser.add_argument('--data_path', default='', type=str,
                        help='dataset path')
    parser.add_argument('--nb_classes', default=2, type=int,
                        help='number of the classification types')
    parser.add_argument('--output_dir', default='',
                        help='path where to save, empty for no saving')
    parser.add_argument('--log_dir', default=None,
                        help='path where to tensorboard log')
    parser.add_argument('--device', default='cuda',
                        help='device to use for training / testing')
    parser.add_argument('--seed', default=None, type=int)
    parser.add_argument('--resume', default='',
                        help='resume from checkpoint')
    parser.add_argument('--eval_data_path', default=None, type=str,
                        help='dataset path for evaluation')
    parser.add_argument('--imagenet_default_mean_and_std', type=str2bool, default=True)
    parser.add_argument('--data_set', default='IMNET', choices=['CIFAR', 'IMNET', 'image_folder'],
                        type=str, help='ImageNet dataset path')
    parser.add_argument('--auto_resume', type=str2bool, default=True)
    parser.add_argument('--save_ckpt', type=str2bool, default=True)
    parser.add_argument('--save_ckpt_freq', default=5, type=int)
    parser.add_argument('--save_ckpt_num', default=1000, type=int)
    parser.add_argument('--start_epoch', default=0, type=int, metavar='N',
                        help='start epoch')
    parser.add_argument('--eval', type=str2bool, default=False,
                        help='Perform evaluation only')
    parser.add_argument('--dist_eval', type=str2bool, default=True,
                        help='Enabling distributed evaluation')
    parser.add_argument('--disable_eval', action='store_true',
                        help='Disabling evaluation during training')
    parser.add_argument('--num_workers', default=8, type=int)
    parser.add_argument('--pin_mem', type=str2bool, default=True,
                        help='Pin CPU memory in DataLoader for more efficient transfer to GPU.')

    # Evaluation parameters.
    parser.add_argument('--crop_pct', type=float, default=None)

    # Distributed training parameters.
    parser.add_argument('--world_size', default=1, type=int,
                        help='number of distributed processes')
    parser.add_argument('--local_rank', default=-1, type=int)
    parser.add_argument('--local-rank', default=-1, type=int)
    parser.add_argument('--dist_on_itp', type=str2bool, default=False)
    parser.add_argument('--dist_url', default='env://',
                        help='url used to set up distributed training')
    parser.add_argument('--use_amp', action='store_true',
                        help="Use apex AMP (Automatic Mixed Precision) or not")

    return parser


def seed_everything(seed, deterministic=False):
    """Set random seed for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def build_model(args):
    """Build the LCCO-Net model (or a ResNet-50 baseline)."""
    if args.model in ('LCCONet', 'LCCO-Net', 'TwoBranchLCCONet'):
        if args.backbone == 'convnext':
            model = lcco_net_convnext(
                num_classes=args.nb_classes, alpha=args.alpha,
                base_margin=args.base_margin, margin_coeff=args.margin_coeff)
        else:
            model = lcco_net_resnet(
                num_classes=args.nb_classes, alpha=args.alpha,
                base_margin=args.base_margin, margin_coeff=args.margin_coeff)
    elif args.model in ('resnet50', 'ResNet-50'):
        model = resnet50(num_classes=args.nb_classes)
    else:
        model = timm.create_model(args.model, pretrained=args.pretrained,
                                   num_classes=args.nb_classes)
    return model


def main(args):

    utils.init_distributed_mode(args)
    print(args)

    if args.seed is not None:
        seed = args.seed + utils.get_rank()
        seed_everything(seed, True)
    device = torch.device(args.device)
    num_tasks = utils.get_world_size()
    global_rank = utils.get_rank()

    # Init train & test datasets.
    if not args.eval:
        dataset_train = TrainDataset(is_train=True, args=args)
        sampler_train = torch.utils.data.DistributedSampler(
            dataset_train, num_replicas=num_tasks, rank=global_rank, shuffle=True,
        )
        print("Sampler_train = %s" % str(sampler_train))

        if args.disable_eval:
            args.dist_eval = False
            dataset_val = None
        else:
            dataset_val = TrainDataset(is_train=False, args=args)

        if args.dist_eval:
            if len(dataset_val) % num_tasks != 0:
                print('Warning: Enabling distributed evaluation with an eval dataset not divisible '
                      'by process number. This will slightly alter validation results.')
            sampler_val = torch.utils.data.DistributedSampler(
                dataset_val, num_replicas=num_tasks, rank=global_rank, shuffle=False)
        else:
            sampler_val = torch.utils.data.SequentialSampler(dataset_val)

        if global_rank == 0 and args.log_dir is not None:
            os.makedirs(args.log_dir, exist_ok=True)
            log_writer = utils.TensorboardLogger(log_dir=args.log_dir)
        else:
            log_writer = None

        data_loader_train = torch.utils.data.DataLoader(
            dataset_train, sampler=sampler_train,
            batch_size=args.batch_size,
            num_workers=args.num_workers,
            pin_memory=args.pin_mem,
            drop_last=True,
        )
        if dataset_val is not None:
            data_loader_val = torch.utils.data.DataLoader(
                dataset_val, sampler=sampler_val,
                batch_size=1 if args.transform_mode == 'source' else args.batch_size,
                num_workers=args.num_workers,
                pin_memory=args.pin_mem,
                drop_last=False,
            )
        else:
            data_loader_val = None

    # Init model.
    model = build_model(args)
    model.to(device)

    mixup_fn = None
    mixup_active = args.mixup > 0 or args.cutmix > 0. or args.cutmix_minmax is not None
    if mixup_active:
        print("Mixup is activated!")
        mixup_fn = Mixup(
            mixup_alpha=args.mixup, cutmix_alpha=args.cutmix, cutmix_minmax=args.cutmix_minmax,
            prob=args.mixup_prob, switch_prob=args.mixup_switch_prob, mode=args.mixup_mode,
            label_smoothing=args.smoothing, num_classes=args.nb_classes)

    model_ema = None
    if args.model_ema:
        model_ema = ModelEma(
            model,
            decay=args.model_ema_decay,
            device='cpu' if args.model_ema_force_cpu else '',
            resume='')
        print("Using EMA with decay = %.8f" % args.model_ema_decay)

    model_without_ddp = model
    n_parameters = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Number of params: {n_parameters/1e6:.2f}M")

    eff_batch_size = args.batch_size * args.update_freq * utils.get_world_size()
    if not args.eval:
        num_training_steps_per_epoch = len(dataset_train) // eff_batch_size

    if args.lr is None:
        args.lr = args.blr * eff_batch_size / 256
    print("Base lr: %.2e" % (args.lr * 256 / eff_batch_size))
    print("Actual lr: %.2e" % args.lr)
    print("Accumulate grad iterations: %d" % args.update_freq)
    print("Effective batch size: %d" % eff_batch_size)

    if args.layer_decay < 1.0 or args.layer_decay > 1.0:
        assert args.layer_decay_type in ['single', 'group']
        if args.layer_decay_type == 'group':
            num_layers = 12
        else:
            num_layers = sum(model_without_ddp.depths)
        assigner = LayerDecayValueAssigner(
            list(args.layer_decay ** (num_layers + 1 - i) for i in range(num_layers + 2)),
            depths=model_without_ddp.depths, layer_decay_type=args.layer_decay_type)
    else:
        assigner = None

    if assigner is not None:
        print("Assigned values = %s" % str(assigner.values))

    if args.distributed:
        model = torch.nn.parallel.DistributedDataParallel(
            model, device_ids=[args.gpu], find_unused_parameters=False)
        model_without_ddp = model.module

    optimizer = create_optimizer(
        args, model_without_ddp, skip_list=None,
        get_num_layer=assigner.get_layer_id if assigner is not None else None,
        get_layer_scale=assigner.get_scale if assigner is not None else None)
    loss_scaler = NativeScaler()

    if mixup_fn is not None:
        criterion = SoftTargetCrossEntropy()
    elif args.smoothing > 0.:
        criterion = LabelSmoothingCrossEntropy(smoothing=args.smoothing)
    else:
        criterion = torch.nn.CrossEntropyLoss()
    print("criterion = %s" % str(criterion))

    utils.auto_load_model(
        args=args, model=model, model_without_ddp=model_without_ddp,
        optimizer=optimizer, loss_scaler=loss_scaler, model_ema=model_ema)

    # ------------------------------------------------------------------ #
    # Evaluation-only mode.
    # ------------------------------------------------------------------ #
    if args.eval:
        model.eval()
        print(f"Eval only mode")

        ROOT = args.eval_data_path
        # Generator sub-directories for the two benchmarks used in the paper.
        # AIGCDetectBenchmark (trained on ProGAN, tested on 8 generators).
        # GenImage (trained on SDv1.4, tested on 7 generators).
        VAL_DICT = {
            "AIGCDetectBenchmark": [
                'progan', 'biggan', 'cyclegan', 'adm', 'wfir',
                'sdv1.4', 'sdv1.5', 'midjourney',
            ],
            "GenImage": [
                'stable_diffusion_v_1_4', 'stable_diffusion_v_1_5',
                'ADM', 'BigGAN', 'wukong', 'VQDM', 'Midjourney',
            ],
        }
        try:
            vals = VAL_DICT[os.path.basename(os.path.normpath(args.eval_data_path))]
        except KeyError:
            vals = sorted(os.listdir(args.eval_data_path))

        rows = [["{} model testing on...".format(args.resume)],
                ['testset', 'accuracy', 'avg precision', 'realacc', 'fakeacc']]

        for v_id, val in enumerate(vals):
            args.eval_data_path = os.path.join(ROOT, val)
            dataset_val = TrainDataset(is_train=False, args=args)

            if args.dist_eval:
                if len(dataset_val) % num_tasks != 0:
                    print('Warning: Enabling distributed evaluation with an eval dataset '
                          'not divisible by process number.')
                sampler_val = torch.utils.data.DistributedSampler(
                    dataset_val, num_replicas=num_tasks, rank=global_rank, shuffle=False)
            else:
                sampler_val = torch.utils.data.SequentialSampler(dataset_val)

            data_loader_val = torch.utils.data.DataLoader(
                dataset_val, sampler=sampler_val,
                batch_size=1 if args.transform_mode == 'source' else args.batch_size,
                num_workers=args.num_workers,
                pin_memory=args.pin_mem,
                drop_last=False
            )

            test_stats, acc, ap, realacc, fakeacc = evaluate(
                data_loader_val, model, device, val)
            print(f"Accuracy of the network on {len(dataset_val)} test images: "
                  f"{test_stats['acc1']:.2%}")
            print(f"test dataset is {val} acc: {acc:.2%}, ap: {ap:.2%}, "
                  f"realacc: {realacc:.2%}, fakeacc: {fakeacc:.2%}")
            print("***********************************")

            rows.append([val, acc * 100, ap * 100, realacc * 100, fakeacc * 100])

        def calculate_column_means(rows):
            if not rows or len(rows[0]) < 2:
                raise ValueError("The input rows list is empty or lacks numeric columns.")
            num_columns = len(rows[0]) - 1
            means = ['mean'] + [sum(row[i] for row in rows) / len(rows)
                                for i in range(1, num_columns + 1)]
            return means
        rows.append(calculate_column_means(rows[2:]))

        test_dataset_name = os.path.basename(os.path.normpath(ROOT))
        csv_name = os.path.join(args.output_dir,
                                f'{os.path.basename(args.resume)}_{test_dataset_name}.csv')
        with open(csv_name, 'w') as f:
            csv_writer = csv.writer(f, delimiter=',')
            csv_writer.writerows(rows)
        return

    # ------------------------------------------------------------------ #
    # Training loop.
    # ------------------------------------------------------------------ #
    max_accuracy = 0.0
    if args.model_ema and args.model_ema_eval:
        max_accuracy_ema = 0.0

    print("Start training for %d epochs" % args.epochs)
    start_time = time.time()
    for epoch in range(args.start_epoch, args.epochs):
        if args.distributed:
            data_loader_train.sampler.set_epoch(epoch)
        if log_writer is not None:
            log_writer.set_step(epoch * num_training_steps_per_epoch * args.update_freq)
        train_stats = train_one_epoch(
            model, criterion, data_loader_train,
            optimizer, device, epoch, loss_scaler,
            args.clip_grad, model_ema, mixup_fn,
            log_writer=log_writer, args=args,
        )
        if args.output_dir and args.save_ckpt:
            if (epoch + 1) % args.save_ckpt_freq == 0 or epoch + 1 == args.epochs:
                utils.save_model(
                    args=args, model=model, model_without_ddp=model_without_ddp,
                    optimizer=optimizer, loss_scaler=loss_scaler, epoch=epoch,
                    model_ema=model_ema)
                utils.save_model(
                    args=args, model=model, model_without_ddp=model_without_ddp,
                    optimizer=optimizer, loss_scaler=loss_scaler, epoch='last',
                    model_ema=model_ema)
        if data_loader_val is not None:
            test_stats = evaluate(data_loader_val, model, device, use_amp=args.use_amp)[0]
            print(f"Accuracy of the model on the {len(data_loader_val)} test images: "
                  f"{test_stats['acc1']:.2%}")
            if max_accuracy < test_stats["acc1"]:
                max_accuracy = test_stats["acc1"]
                if args.output_dir and args.save_ckpt:
                    utils.save_model(
                        args=args, model=model, model_without_ddp=model_without_ddp,
                        optimizer=optimizer, loss_scaler=loss_scaler, epoch="best",
                        model_ema=model_ema)
            print(f'Max accuracy: {max_accuracy:.2%}')

            if log_writer is not None:
                log_writer.update(test_acc1=test_stats['acc1'], head="perf", step=epoch)
                log_writer.update(test_loss=test_stats['loss'], head="perf", step=epoch)

            log_stats = {**{f'train_{k}': v for k, v in train_stats.items()},
                         **{f'test_{k}': v for k, v in test_stats.items()},
                         'epoch': epoch,
                         'n_parameters': n_parameters}

            if args.model_ema and args.model_ema_eval:
                test_stats_ema = evaluate(
                    data_loader_val, model_ema.ema, device, use_amp=args.use_amp)[0]
                print(f"Accuracy of the model EMA on {len(data_loader_val)} test images: "
                      f"{test_stats_ema['acc1']:.2%}")
                if max_accuracy_ema < test_stats_ema["acc1"]:
                    max_accuracy_ema = test_stats_ema["acc1"]
                    if args.output_dir and args.save_ckpt:
                        utils.save_model(
                            args=args, model=model, model_without_ddp=model_without_ddp,
                            optimizer=optimizer, loss_scaler=loss_scaler, epoch="best-ema",
                            model_ema=model_ema)
                    print(f'Max EMA accuracy: {max_accuracy_ema:.2%}')
                if log_writer is not None:
                    log_writer.update(test_acc1_ema=test_stats_ema['acc1'],
                                      head="perf", step=epoch)
                log_stats.update({**{f'test_{k}_ema': v for k, v in test_stats_ema.items()}})
        else:
            log_stats = {**{f'train_{k}': v for k, v in train_stats.items()},
                         'epoch': epoch,
                         'n_parameters': n_parameters}

        if args.output_dir and utils.is_main_process():
            if log_writer is not None:
                log_writer.flush()
            with open(os.path.join(args.output_dir, "log.txt"), mode="a", encoding="utf-8") as f:
                f.write(json.dumps(log_stats) + "\n")

    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print('Training time {}'.format(total_time_str))


if __name__ == '__main__':
    parser = argparse.ArgumentParser('LCCO-Net fine-tuning', parents=[get_args_parser()])
    args = parser.parse_args()
    if args.output_dir:
        Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    main(args)
